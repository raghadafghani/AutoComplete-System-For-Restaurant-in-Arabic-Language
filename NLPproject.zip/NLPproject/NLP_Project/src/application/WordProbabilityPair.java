package application;

public class WordProbabilityPair {

	String word;
    CorpusRecord record;

    WordProbabilityPair(String word, CorpusRecord record) {
        this.word = word;
        this.record = record;
    }
}
